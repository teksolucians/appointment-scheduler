<?php
session_start();
// Unset all session variables
$_SESSION = array();
// Destroy the session
session_destroy();
// Redirect to the login page

header("refresh:2;url=register.html");
echo "User Successfully Logged Out.<br><br>";
echo "Redirecting to the Log In Page<br>";
exit();
?>