<?php
session_start();
/////////////////////////INITIAL SETUP///////////////////////////
include "db_connect.php"; //CONNECT TO OUR LOCALHOST SERVER
$email = $_POST['email'];
$password = $_POST['password'];
/**********************SIGN UP LOGIC ********************/
if (isset($_POST['signUp'])){
$hashed_password = password_hash($password, PASSWORD_BCRYPT);
//hash password for security in case of a data breach
$username = $_POST['username'];
$sql = "SELECT email FROM members;";
$check_duplicate_email_object = mysqli_query($server_connection, $sql);
while ($row = mysqli_fetch_assoc($check_duplicate_email_object)){
if ($email==$row['email']) {
echo "ERROR: E-mail address already exists";
header("refresh:3;url=register.html");
die();
}
}
$new_member = "INSERT INTO `members` (`username`, `email`, `password` ) VALUES ('$username', '$email', '$hashed_password');";
$create_member = mysqli_query($server_connection, $new_member);
if (!$create_member){
die("Error creating new member <br>" . mysqli_error($server_connection));
}else {

header("refresh:2.5;url=register.html");
echo "<b>Successfully created new account </b>";
echo "<br>WELCOME $username!";
echo "<br>Redircting you to LOG IN PAGE";
}
}
//////////////////////////////////END OF SIGN UP SECTION////////////////////////////

/****************************************** LOG IN LOGIC **********************/

if (isset($_POST['login'])){
$email_match = False;
$retrieve_credentials_query = "SELECT * FROM members";
$retrieve_credentials_result = mysqli_query($server_connection, $retrieve_credentials_query);
if (!$retrieve_credentials_result) {
die("Error retreiving email password pair ".mysqli_error($server_connection));
}else{
while($row = mysqli_fetch_assoc($retrieve_credentials_result)){
$email_stored = $row['email'];
$password_stored = $row['password'];
$username_stored = $row['username'];
$USER_ID = $row['USER_ID'];

if ($email_stored == $email){
$email_match = True;
if (password_verify($password, $password_stored)){

$_SESSION['USER_ID'] = $USER_ID;
$_SESSION['username'] = $username_stored;
$_SESSION['email'] = $email_stored;
if ($email=="admin@admin.com"){
header("refresh:1;url=admin_dashboard.php");
}
else {
header("refresh:.1;url=catalogue.php");
//die();
}
} else {
header("refresh:3;url=register.html");
echo "You have entered an incorrect password ";
}

}
}
if ($email_match==False){
    header("refresh:2;url=register.html");
    echo "email does not exist in records";

}
}
}
?>