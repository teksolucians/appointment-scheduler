document.getElementById('locationSelector').addEventListener('change', function()
{
var selectedValue = this.value;
// Toggle visibility of the map based on the selected option
if (selectedValue === 'On site') {
document.getElementById('map').style.display = 'block';
} else {
document.getElementById('map').style.display = 'none';
}
});