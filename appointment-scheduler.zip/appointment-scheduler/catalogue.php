<?php
session_start();
$USER_ID = $_SESSION['USER_ID'];
$username = $_SESSION['username'];
if (!$username){
$username = "valued customer";
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Catologue - Appointment Scheduler</title>
<link rel="icon" type="image/x-icon" href="images/greenNineOClock.ico"> <!--My custom page icon -->
<link rel="canonical" href="https://getbootstrap.com/docs/5.2/examples/album/">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
<link href = "css/owen.css" type="text/css" rel="stylesheet">

</head>
<body class="bg-warning">
<header>
<div class="collapse bg-dark" id="navbarHeader">
<div class="container">
<div class="row">
<div class="col-sm-8 col-md-7 py-4">
<h4 class="text-white">Web Programming Project</h4>
<p class="text-muted">An innovative Web Site created by the regional UTT
student Owen Elwin. This digital tool is an Appointment Scheduler for
<b><i><b><i>BUSY</i></b> </i></b>people. </p>
</div>
<div class="col-sm-4 offset-md-1 py-4">
<h4 class="text-white appointment_scheduler_navbar">Appointment
Scheduler</h4>
<ul class="list-untaskd">

<li><a href="catalogue.php" class="text-white">Home</a></li>
<li><a href="customer_dashboard.php"

class="text-white">Dashboard</a></li>

<li><a href="logout.php" class="text-white">Log Out</a></li>

</ul>
</div>
</div>
</div>
</div>
<div class="navbar navbar-dark bg-dark shadow-sm"><marquee
id="greeting"><?php echo "Welcome {$username}"?></marquee>
<div class="container">
<button class="navbar-toggler" type="button" data-bs-toggle="collapse"
data-bs-target="#navbarHeader" aria-controls="navbarHeader"
aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span>
</button>
</div>
</div>
</header>
<main>
<section>
<center>
<img src="images/greenNineOClock.ico" id="NineOClock">
<h2 class="appointment_scheduler_heading">Appointment Scheduler</h2>

<br>

</center>
</section>
<div class="album py-5 bg-light">
<div class="container">
<div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">

<div class="col">
<div class="card shadow-sm">
<img src = "images/LocksWomen1.png" alt="Locks pic" class="task">

<div class="card-body">
<p class="card-text">Locks</p>
<div class="d-flex justify-content-between align-items-center">
<div class="btn-group">
<a href="appointment_requests.php"><button type="button" class="btn

btn-sm btn-outline-secondary">Book Appointment Now</button></a>

</div>
<small class="text-muted">3 hours</small>
</div>
</div>
</div>
</div>
<div class="col">
<div class="card shadow-sm">
<img src = "images/LocksWomen5.png" alt="Locks pic" class="task">
<div class="card-body">
<p class="card-text">Locks</p>
<div class="d-flex justify-content-between align-items-center">
<div class="btn-group">
<a href="appointment_requests.php"><button type="button" class="btn

btn-sm btn-outline-secondary">Book Appointment Now</button></a>

</div>
<small class="text-muted">3 hours</small>
</div>
</div>
</div>
</div>
<div class="col">
<div class="card shadow-sm">
<img src = "images/LocksWomen3.png" alt="Locks pic" class="task">
<div class="card-body">
<p class="card-text">Locks</p>
<div class="d-flex justify-content-between align-items-center">
<div class="btn-group">
<a href="appointment_requests.php"><button type="button" class="btn

btn-sm btn-outline-secondary">Book Appointment Now</button></a>

</div>
<small class="text-muted">3 hours</small>
</div>

</div>
</div>
</div>

<div class="col">
<div class="card shadow-sm">
<img src = "images/BraidsWomen4.png" height="100%" alt="Braids pic"
class="task">
<div class="card-body">
<p class="card-text"task="text-align:center">Braids</p>
<div class="d-flex justify-content-between align-items-center">
<div class="btn-group">
<a href="appointment_requests.php"><button type="button" class="btn

btn-sm btn-outline-secondary">Book Appointment Now</button></a>

</div>
<small class="text-muted">4 hours</small>
</div>
</div>
</div>
</div>
<div class="col">
<div class="card shadow-sm">
<img src = "images/BraidsWomen2.png" height="100%" alt="Braids pic"
class="task">
<div class="card-body">
<p class="card-text">Braids</p>
<div class="d-flex justify-content-between align-items-center">
<div class="btn-group">
<a href="appointment_requests.php"><button type="button" class="btn

btn-sm btn-outline-secondary">Book Appointment Now</button></a>

</div>
<small class="text-muted">4 hours</small>
</div>
</div>
</div>
</div>
<div class="col">
<div class="card shadow-sm">

<img src = "images/BraidsWomen3.png" alt="Braids pic" class="task">
<div class="card-body">
<p class="card-text">Braids</p>
<div class="d-flex justify-content-between align-items-center">
<div class="btn-group">
<a href="appointment_requests.php"><button type="button" class="btn

btn-sm btn-outline-secondary">Book Appointment Now</button></a>

</div>
<small class="text-muted">4 hours</small>
</div>
</div>
</div>
</div>
<div class="col">
<div class="card shadow-sm">
<img src = "images/CornrowMen5.png" alt="Cornrows pic" class="task">
<div class="card-body">
<p class="card-text">Cornrows</p>
<div class="d-flex justify-content-between align-items-center">
<div class="btn-group">
<a href="appointment_requests.php"><button type="button" class="btn

btn-sm btn-outline-secondary">Book Appointment Now</button></a>

</div>
<small class="text-muted">30 mins</small>
</div>
</div>
</div>
</div>
<div class="col">
<div class="card shadow-sm">
<img src = "images/CornrowMen4.png" alt="Cornrows pic" class="task">
<div class="card-body">
<p class="card-text">Cornrows</p>
<div class="d-flex justify-content-between align-items-center">
<div class="btn-group">
<a href="appointment_requests.php"><button type="button" class="btn

btn-sm btn-outline-secondary">Book Appointment Now</button></a>

</div>
<small class="text-muted">30 mins</small>
</div>
</div>
</div>
</div>
<div class="col">
<div class="card shadow-sm">
<img src = "images/CornrowMen3.png" alt="Cornrows pic" class="task">
<div class="card-body">
<p class="card-text">Cornrows</p>
<div class="d-flex justify-content-between align-items-center">
<div class="btn-group">
<a href="appointment_requests.php"><button type="button" class="btn

btn-sm btn-outline-secondary">Book Appointment Now</button></a>

</div>
<small class="text-muted">30 mins</small>
</div>
</div>
</div>
</div>

<div class="col">
<div class="card shadow-sm">
<img src = "images/manicure1.jfif" alt="Manicure pic" class="task">
<div class="card-body">
<p class="card-text">Manicure</p>
<div class="d-flex justify-content-between align-items-center">
<div class="btn-group">
<a href="appointment_requests.php"><button type="button" class="btn

btn-sm btn-outline-secondary">Book Appointment Now</button></a>

</div>
<small class="text-muted">45 mins</small>
</div>
</div>
</div>
</div>

<div class="col">
<div class="card shadow-sm">
<img src = "images/manicure5.png" alt="Manicure pic" class="task">
<div class="card-body">
<p class="card-text">Manicure</p>
<div class="d-flex justify-content-between align-items-center">
<div class="btn-group">
<a href="appointment_requests.php"><button type="button" class="btn

btn-sm btn-outline-secondary">Book Appointment Now</button></a>

</div>
<small class="text-muted">45 mins</small>
</div>
</div>
</div>
</div>
<div class="col">
<div class="card shadow-sm">
<img src = "images/pedicure3.jpg" alt="Pedicure pic" class="task">
<div class="card-body">
<p class="card-text">Pedicure</p>
<div class="d-flex justify-content-between align-items-center">
<div class="btn-group">
<a href="appointment_requests.php"><button type="button" class="btn

btn-sm btn-outline-secondary">Book Appointment Now</button></a>

</div>
<small class="text-muted">45 mins</small>
</div>
</div>
</div>
</div>

<div class="col">
<div class="card shadow-sm">
<img src = "images/math.jfif" alt="Math pic" class="task">
<div class="card-body">
<p class="card-text">Math Lessons</p>
<div class="d-flex justify-content-between align-items-center">

<div class="btn-group">
<a href="appointment_requests.php"><button type="button" class="btn

btn-sm btn-outline-secondary">Book Appointment Now</button></a>

</div>
<small class="text-muted">2 Hours</small>
</div>
</div>
</div>
</div>
<div class="col">
<div class="card shadow-sm">
<img src = "images/spanish3.png" alt="Spanish pic" class="task">
<div class="card-body">
<p class="card-text">Spanish Lessons</p>
<div class="d-flex justify-content-between align-items-center">
<div class="btn-group">
<a href="appointment_requests.php"><button type="button" class="btn

btn-sm btn-outline-secondary">Book Appointment Now</button></a>

</div>
<small class="text-muted">2 Hours</small>
</div>
</div>
</div>
</div>
<div class="col">
<div class="card shadow-sm">
<img src = "images/WebDesignLessons.jfif" alt="Web Design Lessons pic"
class="task">
<div class="card-body">
<p class="card-text">Web Programming Lessons</p>
<div class="d-flex justify-content-between align-items-center">
<div class="btn-group">
<a href="appointment_requests.php"><button type="button" class="btn

btn-sm btn-outline-secondary">Book Appointment Now</button></a>

</div>
<small class="text-muted">2 Hours</small>
</div>
</div>
</div>

</div>

</div>
</div>
</div>
</main>
<footer class="text-muted py-5">
<div class="container">

<h6>Calcutta Rd 1</h6>
<h6>Freeport</h6>
<h6>Couva</h6>
<p class="float-end mb-1">
<a href="#">Back to top</a>
</p>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</footer>
</html>