
var duration = document.getElementById("duration");
var task = document.getElementById("task");

function updateDuration(){ //This function updates the duration DISPLAYED for each hair task dynamically
if (task.value=="Braids"){
duration.innerHTML = "&nbsp;&nbsp;4 Hours";
}

if (task.value=="Cornrows"){
duration.innerHTML = "&nbsp;&nbsp;30 Minutes";
}

if (task.value=="Locks"){
duration.innerHTML = "&nbsp;&nbsp;3 Hours";
}

if (task.value=="Manicure"){
duration.innerHTML = "&nbsp;&nbsp;45 Minutes";
}

if (task.value=="Pedicure"){
duration.innerHTML = "&nbsp;&nbsp;45 Minutes";
}

if (task.value=="Math"){
duration.innerHTML = "&nbsp;&nbsp;2 Hours";
}

if (task.value=="Spanish"){
duration.innerHTML = "&nbsp;&nbsp;2 Hours";

}

if (task.value=="Web"){
duration.innerHTML = "&nbsp;&nbsp;2 Hours";
}
}

task.addEventListener("change",updateDuration);