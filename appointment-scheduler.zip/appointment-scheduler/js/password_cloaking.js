document.querySelectorAll('.toggle-password').forEach(function (toggle) {
toggle.addEventListener('click', function () {
const passwordField = document.querySelector(this.getAttribute('toggle'));
if (passwordField.type === 'password') {
passwordField.type = 'text';
this.textContent = 'Hide';
} else {
passwordField.type = 'password';
this.textContent = ' Show 👁 ';
}
});
});