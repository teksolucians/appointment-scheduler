<?php
session_start();
$USER_ID = $_SESSION['USER_ID'];
$username = $_SESSION['username'];
if (!$username){
$username = "valued customer";
}
include "db_connect.php"; //CONNECT TO OUR LOCALHOST SERVER

$appointments_sql = 'SELECT task, location, day, `Start_Time`, duration, notes
FROM appointments;';
$members_sql = 'SELECT username, email FROM members;';
$appointments_query = mysqli_query($server_connection, $appointments_sql);
$members_query = mysqli_query($server_connection, $members_sql);
if (!$appointments_query){
echo 'Error in retreiving appointment data ';
}
if (!$members_query){
echo 'Error in retreiving members data ';
}

mysqli_data_seek($appointments_query, 0); // Resets the pointer to the beginning of the result set
mysqli_data_seek($appointments_query, mysqli_num_rows($appointments_query)-1); //selects the very last row inserted into our table
$appointments_tuple = mysqli_fetch_assoc($appointments_query);

$task = $appointments_tuple['task'];
$duration = $appointments_tuple['duration'];
$location = $appointments_tuple['location'];
$day = $appointments_tuple['day'];
$Start_Time = $appointments_tuple['Start_Time'];
$notes = $appointments_tuple['notes'];

$email = $_SESSION['email'];
$username=$_SESSION['username'];
mysqli_close($server_connection);

echo "<!doctype html>
<html lang='en'>
<head>
<meta charset='utf-8'>
<meta name='viewport' content='width=device-width, initial-scale=1'>
<title>Appointment Scheduler</title>
<link rel='icon' type='image/x-icon' href='images/greenNineOClock.ico'>
<!--My custom page icon -->
<link rel='canonical' href='https://getbootstrap.com/docs/5.2/examples/album/'>
<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css' rel='stylesheet' integrity='sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN' crossorigin='anonymous'>
<link href='css/owen.css' rel='stylesheet' type='text/css'>
</head>
<body class='bg-warning'>
<header>
<div class='collapse bg-dark' id='navbarHeader'>
<div class='container'>
<div class='row'>
<div class='col-sm-8 col-md-7 py-4'>
<h4 class='text-white'>Web Programming Project</h4>
<p class='text-muted'>An innovative Web Site created by the regional UTT
student Owen Elwin. This digital tool is an Appointment Scheduler for
<b><i>BUSY</i></b> people. </p>
</div>
<div class='col-sm-4 offset-md-1 py-4'>
<h4 class='text-white appointment_scheduler_navbar'><br>Appointment
Scheduler</h4>
<ul class='list-untaskd'>
<li><a href='catalogue.php' class='text-white'>Home</a></li>

<li><a href='customer_dashboard.php'

class='text-white'>Dashboard</a></li>

<li><a href='logout.php' class='text-white'>Log Out</a></li>
</ul>
</div>
</div>
</div>
</div>
<div class='navbar navbar-dark bg-dark shadow-sm'>
<div class='container'>
<button class='navbar-toggler' type='button' data-bs-toggle='collapse'
data-bs-target='#navbarHeader' aria-controls='navbarHeader' aria-expanded='false'
aria-label='Toggle navigation'>
<span class='navbar-toggler-icon'></span>
</button>
</div>
</div>
</header>
<main>
<section>
<center>

<img src='images/greenNineOClock.ico' id='NineOClock'>
<h2 class='appointment_scheduler_heading'>Appointment Scheduler</h2>
<br>
<h3>THANK YOU $username for choosing Appointment Scheduler Ltd. </h3>
<br>
<h5> Your Appointment Details are as follows: </h5>
<br>
<table class='appointment_table'>
<tr><td> Username: </td><td> &nbsp;&nbsp;$username </td></tr>
<tr><td> Task: </td> <td>&nbsp;&nbsp;$task</td></tr>
<tr><td>Duration:</td><td>&nbsp;&nbsp;$duration</td></tr>
<tr><td>Location:</td><td>&nbsp;&nbsp;$location</td></tr>
<tr><td>E-mail:</td><td>&nbsp;&nbsp;$email</td></tr>
<tr><td>Day:</td><td>&nbsp;&nbsp;$day</td></tr>
<tr><td>Start Time:</td><td>&nbsp;&nbsp;$Start_Time</td></tr>
<tr><td>Extra Notes: </td><td>&nbsp;&nbsp;$notes</td></tr>
</table>

</center>

</section>
</main>
<footer class='text-muted py-5'>
<div class='container'>

<h6>Calcutta Rd 1</h6>
<h6>Freeport</h6>
<h6>Couva</h6>
<p class='float-end mb-1'>
<a href='#'>Back to top</a>
</p>
</div>
</footer>

<script src='https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js' integrity='sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL' crossorigin='anonymous'></script>
</body>
</html>
";
?>