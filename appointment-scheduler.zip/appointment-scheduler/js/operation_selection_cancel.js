var appointmentDivs = document.getElementsByClassName('appointments');
for (var i = 0; i < appointmentDivs.length; i++) {
    // Add mouseover and mouseout event listeners for highlighting
    appointmentDivs[i].addEventListener('mouseover', function () {
        this.style.backgroundColor = '#d9edf7';
    });
    appointmentDivs[i].addEventListener('mouseout', function () {
        this.style.backgroundColor = '';
    });
    appointmentDivs[i].addEventListener('click', function () {
        var confirmation = confirm("Are you sure you want to delete this appointment?");
        if (confirmation) {
            // appointment ID is stored in a data attribute
            var appointmentID = this.getAttribute('data-appointment-id');
            
            // Check if appointmentID is valid
            if (appointmentID !== null && appointmentID !== undefined) {
                // Send an AJAX request to my PHP script in 'delete_appointment.php' for deletion
                fetch('delete_appointment.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ appointmentID: appointmentID }),
                })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            alert("Appointment deleted successfully!");
                            // update the UI to reflect the deletion
                            this.style.display = 'none'; // Hide the deleted appointment div
                        } else {
                            alert("Error deleting appointment.");
                        }
                    })
                    .catch(error => console.error('Error:', error));
            } else {
                console.error('Invalid appointmentID');
            }
        }
    });
}











/*var appointmentDivs = document.getElementsByClassName('appointments');
for (var i = 0;i < appointmentDivs.length;i++) {
// Add mouseover and mouseout event listeners for highlighting
appointmentDivs[i].addEventListener('mouseover', function() {
this.style.backgroundColor = '#d9edf7';
});
appointmentDivs[i].addEventListener('mouseout', function() {
this.style.backgroundColor = '';
});
appointmentDivs[i].addEventListener('click', function() {
var confirmation = confirm("Are you sure you want to delete this appointment?");
if (confirmation) {
// appointment ID is stored in a data attribute
var appointmentID = this.getAttribute('data-appointment-id');
// Send an AJAX request to my PHP script in 'delete_appointment.php' for deletion
fetch('delete_appointment.php', {
method: 'POST',
headers: {
'Content-Type': 'application/json',
},
body: JSON.stringify({ appointmentID: appointmentID }),
})
.then(response => response.json())
.then(data => {
if (data.success) {
alert("Appointment deleted successfully!");
// update the UI to reflect the deletion
this.task.display = 'none'; // Hide the deleted appointment div
} else {
alert("Error deleting appointment.");
}
})
.catch(error =>console.error('Error:', error));
}
});
}*/