<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Appointment Scheduler</title>
<link rel="icon" type="image/x-icon" href="images/greenNineOClock.ico">
<!--My custom page icon -->
<link rel="canonical" href="https://getbootstrap.com/docs/5.2/examples/album/">
<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css' rel='stylesheet' integrity='sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN' crossorigin='anonymous'>
<link href="css/owen.css" type="text/css" rel = "stylesheet">
</head>
<body class="bg-warning">
<header>
<div class="collapse bg-dark" id="navbarHeader">
<div class="container">
<div class="row">
<div class="col-sm-8 col-md-7 py-4">
<h4 class="text-white">Web Programming Project</h4>
<p class="text-muted">An innovative Web Site created by the regional UTT
student Owen Elwin. This digital tool is an Appointment Scheduler for
<b><i><b><i>BUSY</i></b> </i></b>people. </p>
</div>
<div class="col-sm-4 offset-md-1 py-4">
<h4 class="text-white appointment_scheduler_navbar">Appointment
Scheduler</h4>
<ul class="list-untaskd">
<li><a href="catalogue.php" class="text-white">Home</a></li>

<li><a href="customer_dashboard.php"

class="text-white">Dashboard</a></li>

<li><a href="logout.php" class="text-white">Log Out</a></li>
</ul>
</div>
</div>

</div>
</div>
<div class="navbar navbar-dark bg-dark shadow-sm">
<div class="container">
<button class="navbar-toggler" type="button" data-bs-toggle="collapse"
data-bs-target="#navbarHeader" aria-controls="navbarHeader"
aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span>
</button>
</div>
</div>
</header>
<main >
<section>
<center>

<img src='images/greenNineOClock.ico' id='NineOClock'>
<h2>Appointment Scheduler</h2>
<br>
</center>
</section>

<div class="container appointment_table">
<form action = "requests.php" method="post" onsubmit="return validateForm();">
<table>
<tr><td><p>Task: </p></td><td><p>&nbsp; <select name="task" id="task"><option
value="Braids">Braids</option><option
value="Cornrows">Cornrows</option><option value="Locks">Locks</option><option
value="Manicure">Manicure</option><option
value="Pedicure">Pedicure</option><option value="Math">Math
Lessons</option><option value="Spanish">Spanish Lessons</option><option
value="Web">Web Programming Lessons</option></select></p></td></tr>
<tr><td><p>Duration:</p></td><td><p id = "duration" name="duration"
value="duration">&nbsp;&nbsp;4 Hours</p></td></tr>
<tr><td><p>Location: </p></td><td><p>&nbsp; <select name="location"
id="locationSelector"><option>At home</option><option>On
site</option></select></p></td></tr>
<tr><td><p>Day: </p></td><td><p>&nbsp; <input type="date" name="day"
min="<?php echo date('Y-m-d'); ?>" id="day"></p></td></tr>
<tr><td><p>Time: </p></td><td><p>&nbsp; <input type="time" name = "Start_Time"
id="Start_Time"></p></td></tr>

<tr><td><p>Please share any notes that will help prepare for our appointment:
<p></td><td><p>&nbsp; <input type="text" name="notes"></p></td></tr>
</table><br>
<center><input type="submit" name="submit" value = " Submit "></center>
</form>
</div>

</main>
<center>
<br>
<iframe id="map"
src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d412.432847901
63653!2d-61.42201089805885!3d10.441918715599996!2m3!1f0!2f0!3f0!3m2!1i1024
!2i768!4f13.1!3m3!1m2!1s0x8c35f0d2e099a90f%3A0xbf078a08ee704183!2sHair%2
0and%20Nails%20by%20Kesha!5e0!3m2!1sen!2stt!4v1701806923519!5m2!1sen!2s
tt" width="400" height="400" style="border:2px solid green;" allowfullscreen=""
loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></center>
<footer class='text-muted py-5 container'>
<hr>
<div class='container'>

<h6>Calcutta Rd 1</h6>
<h6>Freeport</h6>
<h6>Couva</h6>
<p class='float-end mb-1'>
<a href='#'>Back to top</a>
</p>
</div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
<script src="js/duration.js"></script>
<script src="js/validate_start_time.js"></script>

<script src="js/show_map.js"></script>
</body>
</html>