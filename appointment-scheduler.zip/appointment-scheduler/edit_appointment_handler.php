<?php
session_start();
$USER_ID = $_SESSION['USER_ID'];
$username = $_SESSION['username'];
if (!$username){
$username = "valued customer";
}

include "db_connect.php"; //CONNECT TO OUR LOCALHOST SERVER

$Appointment_ID = isset($_POST['Appointment_ID']) ? $_POST['Appointment_ID'] :
'';

if ($Appointment_ID !== '') {
echo '<form method="post" action="edit_appointment_handler.php">
<table>
<tr><td> Task: </td> <td> <select name="task" id="task"><option
value="Braids">Braids</option><option
value="Cornrows">Cornrows</option><option
value="Locks">Locks</option></select></td></tr>
<tr><td>Duration</td><td><p id="duration" name="duration" value="duration">1
Hour</p></td></tr>
<tr><td>Location</td><td><select name="location"><option>On
site</option><option>At home</option></select></td></tr>
<tr><td>Day</td><td><input type="date" name="day"></td></tr>
<tr><td>Time</td><td><input type="time" name="Start_Time"></td></tr>
<tr><td>Please share any notes that will help us understand why you needed to
edit your appointment </td><td><input type="text" name="notes"></td></tr>
</table>
<input type="hidden" name="Appointment_ID" value="' . $Appointment_ID . '">
<input type="submit" name="update">
</form>';
if (isset($_POST['update'])) {
$newNotes = $_POST['notes'];

// Use mysqli_real_escape_string to prevent SQL injection
$newNotes = mysqli_real_escape_string($server_connection, $newNotes);
// Update the appointment with the new notes
$edit_sql = "UPDATE appointments SET notes = '$newNotes' WHERE
Appointment_ID = $Appointment_ID";
$edit_query = mysqli_query($server_connection, $edit_sql);
if (!$edit_query) {
die("Error with update query: " . mysqli_error($server_connection));
} else {
echo "Updated successfully!";
}
}
} else {
echo "Error: Appointment ID is missing.";
}
mysqli_close($server_connection);
?>