// Function to format the current date and time in YYYY-MM-DDTHH:mm format
function getCurrentDateTime() {
var now = new Date();
var year = now.getFullYear();
var month = (now.getMonth() + 1).toString().padStart(2, "0");
var day = now.getDate().toString().padStart(2, "0");
var hours = now.getHours().toString().padStart(2, "0");
var minutes = now.getMinutes().toString().padStart(2, "0");
return `${year}-${month}-${day}T${hours}:${minutes}`;
}
// Set the minimum attribute for the time input field
document.getElementById("Start_Time").addEventListener("input", function () {
var selectedDate = document.getElementById("day").value;
var currentDate = getCurrentDateTime();
// Allow any time if the selected date is in the future
if (selectedDate > currentDate.split("T")[0]) {
document.getElementById("Start_Time").min = "00:00";
} else {
// Set the minimum time to the current time if the selected date is today
document.getElementById("Start_Time").min = currentDate.split("T")[1];
}
});
// Set the initial minimum time
document.getElementById("Start_Time").min = getCurrentDateTime().split("T")[1];