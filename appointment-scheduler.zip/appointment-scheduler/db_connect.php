<?php

//connection script.  This PHP script is called by every page which connects to the database.
$server_connection = mysqli_connect("localhost", "id21714455_root", "tmaB!3600");
if (!$server_connection){
die("Error connecting to Server");
}
$create_database = "CREATE DATABASE IF NOT EXISTS `id21714455_hairdresser`;";
mysqli_query($server_connection, $create_database);
mysqli_select_db($server_connection, "id21714455_hairdresser");
$create_members_table = "CREATE TABLE IF NOT EXISTS `members`
(`USER_ID` INT AUTO_INCREMENT PRIMARY KEY, `username` VARCHAR (32),
`email` VARCHAR (32), `password` VARCHAR (255));";
mysqli_query($server_connection, $create_members_table);
$create_appointments_table = "CREATE TABLE IF NOT EXISTS `appointments`
(`APPOINTMENT_ID` INT AUTO_INCREMENT PRIMARY KEY, `USER_ID` INT,`username` VARCHAR(50), `task`
VARCHAR (10), `duration` VARCHAR (10), `location` VARCHAR (10), `email`
VARCHAR (50), `day` DATE, `Start_Time` time, `End_Time` time, `notes` VARCHAR (100));";
mysqli_query($server_connection, $create_appointments_table);



?>