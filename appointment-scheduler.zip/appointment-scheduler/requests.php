<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;    
require 'vendor/autoload.php'; 
session_start();

$USER_ID = $_SESSION['USER_ID'];
$username = $_SESSION['username'];
$email = $_SESSION['email'];
if (!$username){
$username = "valued customer";
}
include "db_connect.php"; //CONNECT TO OUR LOCALHOST SERVER
if (isset($_POST['submit'])){
$task = trim($_POST['task']); //trim() removes white spaces
$location = trim($_POST['location']);
$day = trim($_POST['day']);
$Start_Time = trim($_POST['Start_Time']);
$notes = trim($_POST['notes']);
$End_Time = "";

//CALCULATE Duration and End_Time
if ($task=="Braids"){
$duration = "4 hours";
$End_Time = date('H:i:s', strtotime($Start_Time . ' + ' . $duration));
}
if ($task=="Cornrows"){
$duration = "30 mins";
$End_Time = date("H:i:s", strtotime($Start_Time . " + " . $duration));
}
if ($task=="Locks"){
$duration = "3 hours";
$End_Time = date("H:i:s", strtotime($Start_Time . " + " . $duration));
}
if ($task=="Manicure"){
$duration = "45 minutes";
$End_Time = date('H:i:s', strtotime($Start_Time . ' + ' . $duration));
}
if ($task=="Pedicure"){
$duration = "45 mins";
$End_Time = date("H:i:s", strtotime($Start_Time . " + " . $duration));
}
if ($task=="Math"){

$duration = "2 hours";
$End_Time = date("H:i:s", strtotime($Start_Time . " + " . $duration));
}
if ($task=="Spanish"){
$duration = "2 hours";
$End_Time = date("H:i:s", strtotime($Start_Time . " + " . $duration));
}
if ($task=="Web"){
$duration = "2 hours";
$End_Time = date("H:i:s", strtotime($Start_Time . " + " . $duration));
}

//query to check if a clash with another appointment exists



$clash_query = "SELECT * FROM appointments WHERE day = '$day' AND (
(`Start_Time` < '$End_Time' AND `End_Time` > '$Start_Time') OR
(`Start_Time` < '$End_Time' AND `End_Time` < '$Start_Time' AND `End_Time` > '00:00:00')

)";




$clash_results = mysqli_query($server_connection, $clash_query);
if ($clash_results && mysqli_num_rows($clash_results)>0){
header("refresh:3; url=appointment_requests.php");
echo "Sorry, this time Clashes with an existing appointment. Select another
time frame.";

die();
}else {
$query = "INSERT INTO appointments (`USER_ID`, `username`, `task`, `duration`, `location`,
`day`, `Start_Time`, `End_Time`, `notes`, `email`) VALUES ('$USER_ID', '$username', '$task', '$duration',
'$location', '$day', '$Start_Time', '$End_Time', '$notes', '$email');";
$insert = mysqli_query($server_connection, $query);
if (!$insert){
die("Error in creating order");
} else {header("refresh:30; url=thank_you.php");
        echo "order sent successfully <br> ";
        
     
        //send email section





  
        $business_email = "jennysdoubles@gmail.com";
     
        $mail = new PHPMailer(true);
        try {
            $mail->SMTPOptions = array('ssl'=>array('verify_peer'=>false,'verify_peer_name'=>false,'allow_self_signed' => true));
            //Server settings
            $mail->SMTPDebug = false;//SMTP::DEBUG_SERVER;                   // Enable verbose debug output
            $mail->isSMTP();                                            // Send using SMTP
            $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
            $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
            $mail->Username   = 'jennysdoubles@gmail.com';                     // SMTP username
            $mail->Password   = 'tdxofiypzoqlohtq';                               // SECOND SMTP password (New 3.1.24)
            $mail->SMTPSecure = 'tls';         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
            $mail->Port       = 587;                          // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above

            //Recipients
            $mail->setFrom("jennysdoubles@gmail.com", "New Appointment Order");
            $mail->addAddress($business_email);     // Add a recipient
            
              
            
           $body= "<br> You have just received a new appointment from $username<br>  
           
           <h5> with the following details </h5>
<br>
<table class='appointment_table'>
<tr><td> Username: </td><td> &nbsp;&nbsp;$username </td></tr>
<tr><td> Task: </td> <td>&nbsp;&nbsp;$task</td></tr>
<tr><td>Duration:</td><td>&nbsp;&nbsp;$duration</td></tr>
<tr><td>Location:</td><td>&nbsp;&nbsp;$location</td></tr>
<tr><td>E-mail:</td><td>&nbsp;&nbsp;$email</td></tr>
<tr><td>Day:</td><td>&nbsp;&nbsp;$day</td></tr>
<tr><td>Start Time:</td><td>&nbsp;&nbsp;$Start_Time</td></tr>
<tr><td>Extra Notes: </td><td>&nbsp;&nbsp;$notes</td></tr>
</table>
           
           <br><br>We recommend that you log into appointment scheduler at https://tekso-lucians.000webhostapp.com/appointment-scheduler/register.html to verify that this user has not edited, modified or cancelled his/her appointment ever since from the date/time of this email. <br><br>

<br><br>Appointment Scheduler Inc. <br>
Author: Owen Elwin
<br>
<br><hr>
";
            
            
            
            // Content
            $mail->isHTML(true);                                  // Set email format to HTML
            $mail->Subject = 'New Appointment';
            $mail->Body    = $body;
            $mail->AltBody = strip_tags($body);


            if ($mail->send()){
                echo"Yay";
            }
            else{
                echo"Nay";
            }
        }
        catch (Exception $e) {
            echo "Message could not be sent. Mailer Error: {
               $mail->ErrorInfo
        }";
        
        
            }

}


}
}

?>