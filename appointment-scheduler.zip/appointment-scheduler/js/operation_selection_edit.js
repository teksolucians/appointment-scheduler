var appointmentDivs = document.getElementsByClassName('appointments');
for (var i = 0; i < appointmentDivs.length; i++) {
// Add mouseover and mouseout event listeners for highlighting
appointmentDivs[i].addEventListener('mouseover', function() {
this.style.backgroundColor = '#d9edf7';
});
appointmentDivs[i].addEventListener('mouseout', function() {
this.style.backgroundColor = '';
});
// Add click event listener for editing
appointmentDivs[i].addEventListener('click', function() {
var confirmation = confirm("Are you sure you want to edit this appointment?");
if (confirmation) {
// if user clicks yes the appointment ID is stored from a data attribute
var Appointment_ID = this.getAttribute('data-appointment-id');
console.log(Appointment_ID); //my personal check in the console to verifythat I have correctly identified and captured the correct appointment ID
// I used browser-wide localStorage to store the Appointment_ID
localStorage.setItem('editAppointmentID', Appointment_ID);
// Redirect to the edit appointment page, now that we have the Appointment_ID stored
window.location.href = 'edit_appointment.php';
}
});
}