<?php
// Get the default timezone set on the server
$timezone = date_default_timezone_get();

echo "The current default server timezone is: " . $timezone;
?>

